from flask import *
import json

server = Flask(__name__)


@server.route("/", methods=["GET"])  # Simple Get route
def home():
    name = request.args.get("userid")  # Query params
    return "<h1>Hello, " + name + "</h1>"


@server.route("/login", methods=["POST"])  # Hard-coded login route
def login():
    request_json = request.get_json()  # Get request body (JSON type)
    username = str(request_json["username"])
    password = str(request_json["password"])
    if username == "mohamad" and password == "1234":
        return Response("{status: True}", status=201, mimetype="application/json")  # More sophisticated response
    return Response("{status: False}", status=401, mimetype="application/json")


@server.route("/light", methods=["POST"])  # Save light data route
def save_light():
    data = request.get_json()
    json_obj = json.dumps(data, indent=4)
    with open("light.json", "w") as output:  # Write JSON to file
        output.write(json_obj)
    return Response(status=201)


@server.route("/light", methods=["GET"])  # GET light data route
def get_light():
    file = open("light.json")  # Read JSON from file
    data = json.load(file)
    return data


if __name__ == '__main__':
    server.run(debug=True)
