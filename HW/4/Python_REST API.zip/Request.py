import requests


def main():
    resp = requests.get("http://localhost:5000/?userid=Mohamad")  # Get request
    print(resp.text)

    resp_2 = requests.post("http://localhost:5000/light", json='{"val" = 300}')  # Post request
    print(resp_2)

if __name__ == '__main__':
    main()
